#!/bin/bash
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
ENCODED_DIR="${DIR// /%20}"

CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
EDGE="/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"

if [ -x "$CHROME" ]; then
  BROWSER="$CHROME"
elif [ -x "$EDGE" ]; then
  BROWSER="$EDGE"
else
  echo "Could not find Google Chrome or Microsoft Edge installed on this Mac."
  echo "Please install one of them, then run this script again:"
  echo "  Chrome: https://www.google.com/chrome/"
  echo "  Edge:   https://www.microsoft.com/edge"
  read -p "Press Return to close this window..." _
  exit 1
fi

APP_NAME="Reading Tracker.app"
DEST="$HOME/Desktop/$APP_NAME"

rm -rf "$DEST"
mkdir -p "$DEST/Contents/MacOS" "$DEST/Contents/Resources"

cp "$DIR/icon.icns" "$DEST/Contents/Resources/icon.icns"

cat > "$DEST/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>Reading Tracker</string>
    <key>CFBundleDisplayName</key>
    <string>Reading Tracker</string>
    <key>CFBundleIdentifier</key>
    <string>com.local.readingtracker</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleExecutable</key>
    <string>launcher</string>
    <key>CFBundleIconFile</key>
    <string>icon.icns</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
PLIST

cat > "$DEST/Contents/MacOS/launcher" <<LAUNCHER
#!/bin/bash
exec "$BROWSER" --app="file://$ENCODED_DIR/index.html"
LAUNCHER

chmod +x "$DEST/Contents/MacOS/launcher"

echo "Done! \"Reading Tracker\" app created on your Desktop, using:"
echo "  $BROWSER"
echo "Double-click it on your Desktop (or drag it into your Dock) to use it."
read -p "Press Return to close this window..." _
